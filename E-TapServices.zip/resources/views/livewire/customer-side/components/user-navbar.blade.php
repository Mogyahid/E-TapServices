<div class="px-15 py-5 flex justify-between items-center mb-7">
    <div>
        <!-- <span class="material-icons">home</span> -->
        <a href="/" class="flex items-end hover:text-blue-500">
            <span class="material-icons md-36">home</span> 
            <span class="ml-1 font-medium uppercase">HOME</span>
        </a>
    </div>
    <div>
        <a href="#" class="px-5 py-2 rounded-md hover:text-blue-500">Logout</a>
    </div>
</div>
