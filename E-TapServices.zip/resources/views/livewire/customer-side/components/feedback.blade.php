<div class="my-5">
        <div class="text-center my-7">
            <h1 class="uppercase font-black text-5xl">Satisfied provider feedback</h1>
            <!-- <hr class="bg-blue-500 w-32 h-1 self-center"> -->
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered <br>alteration in some form by injected humour.</p>
        </div>
</div>