<div>
    <div class="px-10 py-7">
        <div >
            <h1 class="font-black uppercase text-2xl">Users</h1>
            <span>Coming soon...</span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/admin-side/components/users.blade.php ENDPATH**/ ?>