<?php $__env->startSection('title', 'E-tap - Let others discover you.'); ?>
<div class="relative">
    <!-- Top navbar -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.top-navbar', [])->html();
} elseif ($_instance->childHasBeenRendered('q2XMqsP')) {
    $componentId = $_instance->getRenderedChildComponentId('q2XMqsP');
    $componentTag = $_instance->getRenderedChildComponentTagName('q2XMqsP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('q2XMqsP');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.top-navbar', []);
    $html = $response->html();
    $_instance->logRenderedChild('q2XMqsP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- Navbar section here -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.navbar', [])->html();
} elseif ($_instance->childHasBeenRendered('fRLXnep')) {
    $componentId = $_instance->getRenderedChildComponentId('fRLXnep');
    $componentTag = $_instance->getRenderedChildComponentTagName('fRLXnep');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fRLXnep');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.navbar', []);
    $html = $response->html();
    $_instance->logRenderedChild('fRLXnep', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <!-- Carousel Section -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.carousel', [])->html();
} elseif ($_instance->childHasBeenRendered('O0jGujn')) {
    $componentId = $_instance->getRenderedChildComponentId('O0jGujn');
    $componentTag = $_instance->getRenderedChildComponentTagName('O0jGujn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('O0jGujn');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.carousel', []);
    $html = $response->html();
    $_instance->logRenderedChild('O0jGujn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.carousel', [])->html();
} elseif ($_instance->childHasBeenRendered('d2uoZT9')) {
    $componentId = $_instance->getRenderedChildComponentId('d2uoZT9');
    $componentTag = $_instance->getRenderedChildComponentTagName('d2uoZT9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d2uoZT9');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.carousel', []);
    $html = $response->html();
    $_instance->logRenderedChild('d2uoZT9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <!-- Main content -->
    <div class="mt-5">
        <div class="text-center my-7">
            <h1 class="uppercase font-black text-5xl">Popular Categories</h1>
            <!-- <hr class="bg-blue-500 w-32 h-1 self-center"> -->
            <p class="font-medium text-xl">Browse service you want in our popular cateories.</p>
        </div>

        <!-- Categories -->
        <div class="grid gap-3 px-15 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 my-4 mb-20 mt-10">
            <!-- Items -->
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border hover:bg-white transform transition hover:-translate-y-2 hover:shadow-md  rounded-md">
                <a href="<?php echo e(route('services', ['category' => $category->id])); ?>">
                    <img src="<?php echo e(asset('/storage/categories/' . $category->image->url)); ?>" class="object-cover w-full rounded-tr-md rounded-tl-md" alt="">
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <!-- How it Works -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.howitworks', [])->html();
} elseif ($_instance->childHasBeenRendered('GdIjEGN')) {
    $componentId = $_instance->getRenderedChildComponentId('GdIjEGN');
    $componentTag = $_instance->getRenderedChildComponentTagName('GdIjEGN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GdIjEGN');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.howitworks', []);
    $html = $response->html();
    $_instance->logRenderedChild('GdIjEGN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Apply as provider -->
    <div class="px-15 flex justify-between py-7 mt-24  items-center">
        <div>
            <!-- <span class="text-gray-600 underline">Apply as provider</span> -->
            <h1 class="text-blue-500 font-bold text-4xl">Become our service provider</h1>
            <p class="font-medium">Yes you read it. You can be one of our partner by just applying to this platform as our provider. <br>Please read and understand carefully the instruction before applying!</p>
        </div>

        <div data-turbolinks="false">
            <a href="/provider_description" class="bg-blue-500 text-white px-10 py-4 rounded hover:shadow-md text-lg uppercase">
                Find out more
            </a>
        </div>
    </div>

    <!-- Footer -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-side.components.footer', [])->html();
} elseif ($_instance->childHasBeenRendered('pB30yAy')) {
    $componentId = $_instance->getRenderedChildComponentId('pB30yAy');
    $componentTag = $_instance->getRenderedChildComponentTagName('pB30yAy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pB30yAy');
} else {
    $response = \Livewire\Livewire::mount('customer-side.components.footer', []);
    $html = $response->html();
    $_instance->logRenderedChild('pB30yAy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/customer-side/index.blade.php ENDPATH**/ ?>