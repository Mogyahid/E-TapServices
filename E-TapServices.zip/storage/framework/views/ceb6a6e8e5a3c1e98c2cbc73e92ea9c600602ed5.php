<div>
    <div class="px-10 py-7">
        <div >
            <h1 class="font-black uppercase text-2xl">Settings</h1>
            <span>Coming soon...</span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/admin-side/components/settings.blade.php ENDPATH**/ ?>