<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<div class="flex relative" x-data="{ page:'dashboard', isLarge:false }">
    <div class="h-screen bg-blue-500 py-5 sticky left-0 top-0 bottom-0" x-show="isLarge">
        <div class="text-white  px-5 mb-5">
            <div class="flex justify-between item-center">
                <button class="focus:outline-none -rotate-180 transform" x-show="isLarge" @click="isLarge =!isLarge"><span class="material-icons">menu_open</span></button>
            </div>
        </div>

        <div class="mt-7 text-white text-center">
            <ul class="space-y-7">
                <li class="bg-white text-blue-500 py-3">
                    <button class="focus:outline-none" @click="page = 'dashboard'">
                        <span class="material-icons align-middle">dashboard</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'request'">
                        <span class="material-icons align-middle">autorenew</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'categories'">
                        <span class="material-icons align-middle">format_align_left</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'providers'">
                        <span class="material-icons align-middle">business_center</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'services'">
                        <span class="material-icons align-middle">drag_indicator</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button  class=" items-center focus:outline-none" @click="page = 'advertisement'">
                        <span class="material-icons align-middle">amp_stories</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'user'">
                        <span class="material-icons align-middle">social_distance</span> 
                    </button>
                </li>
                <li><hr></li>
                <li class="hover:text-gray-300">
                    <button class="items-center focus:outline-none" @click="page = 'settings'">
                        <span class="material-icons align-middle">settings</span> 
                    </button>
                </li>
                <li class="hover:text-gray-300">
                    <a href="<?php echo e(url('/logout')); ?>" class="flex justify-center" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"  class=" items-center focus:outline-none">
                        <span class="material-icons" align-middle>exit_to_app</span> 
                    </a>
                </li>
            </ul>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

    <!-- Width = 64 -->
    <div class="w-64 h-screen bg-blue-500 py-5 sticky left-0 top-0 bottom-0" x-show="!isLarge">
        <div class="text-white  px-5 mb-5">
            <div class="flex justify-between item-center">
                <span class="font-black text-xl">E-TAP</span>
                <button class="focus:outline-none" x-show="!isLarge" @click="isLarge =!isLarge"><span class="material-icons">menu_open</span></button>
            </div>
        </div>

        <div class="mt-7 text-white">
            <ul>
                <li class="bg-white text-blue-500 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'dashboard'">
                        <span class="material-icons">dashboard</span> 
                        <span>Dashboard</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'request'">
                        <span class="material-icons">autorenew</span> 
                        <span>Requests</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'categories'">
                        <span class="material-icons">format_align_left</span> 
                        <span>Category List</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'providers'">
                        <span class="material-icons">business_center</span> 
                        <span>Providers</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'services'">
                        <span class="material-icons">drag_indicator</span> 
                        <span>Services</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button  class="flex space-x-3 items-center focus:outline-none" @click="page = 'advertisement'">
                        <span class="material-icons">amp_stories</span> 
                        <span>Carousel</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'user'">
                        <span class="material-icons">social_distance</span> 
                        <span>Users</span>
                    </button>
                </li>
                <li><hr></li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <button class="flex space-x-3 items-center focus:outline-none" @click="page = 'settings'">
                        <span class="material-icons">settings</span> 
                        <span>Settings</span>
                    </button>
                </li>
                <li class="hover:text-gray-300 px-3 py-3">
                    <a href="<?php echo e(url('/logout')); ?>" class="space-x-3 flex items-center" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"  class="flex space-x-3 items-center focus:outline-none">
                        <span class="material-icons">exit_to_app</span> 
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>

    <!-- Right Side -->

    <!-- Requests List -->

    <!-- Category List -->
    <div x-show="page === 'dashboard'" class="w-full">   
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.dashboard', [])->html();
} elseif ($_instance->childHasBeenRendered('DMNId06')) {
    $componentId = $_instance->getRenderedChildComponentId('DMNId06');
    $componentTag = $_instance->getRenderedChildComponentTagName('DMNId06');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DMNId06');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.dashboard', []);
    $html = $response->html();
    $_instance->logRenderedChild('DMNId06', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'request'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.requests', [])->html();
} elseif ($_instance->childHasBeenRendered('yfFaFSq')) {
    $componentId = $_instance->getRenderedChildComponentId('yfFaFSq');
    $componentTag = $_instance->getRenderedChildComponentTagName('yfFaFSq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yfFaFSq');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.requests', []);
    $html = $response->html();
    $_instance->logRenderedChild('yfFaFSq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'categories'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.categories', [])->html();
} elseif ($_instance->childHasBeenRendered('JBvn7BN')) {
    $componentId = $_instance->getRenderedChildComponentId('JBvn7BN');
    $componentTag = $_instance->getRenderedChildComponentTagName('JBvn7BN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JBvn7BN');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.categories', []);
    $html = $response->html();
    $_instance->logRenderedChild('JBvn7BN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'providers'" class="w-full">   
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.providers', [])->html();
} elseif ($_instance->childHasBeenRendered('cK1TVVH')) {
    $componentId = $_instance->getRenderedChildComponentId('cK1TVVH');
    $componentTag = $_instance->getRenderedChildComponentTagName('cK1TVVH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cK1TVVH');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.providers', []);
    $html = $response->html();
    $_instance->logRenderedChild('cK1TVVH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'advertisement'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.carousel', [])->html();
} elseif ($_instance->childHasBeenRendered('ZBnZt7f')) {
    $componentId = $_instance->getRenderedChildComponentId('ZBnZt7f');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZBnZt7f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZBnZt7f');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.carousel', []);
    $html = $response->html();
    $_instance->logRenderedChild('ZBnZt7f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'user'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.users', [])->html();
} elseif ($_instance->childHasBeenRendered('nnn9zXx')) {
    $componentId = $_instance->getRenderedChildComponentId('nnn9zXx');
    $componentTag = $_instance->getRenderedChildComponentTagName('nnn9zXx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nnn9zXx');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.users', []);
    $html = $response->html();
    $_instance->logRenderedChild('nnn9zXx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'settings'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.components.settings', [])->html();
} elseif ($_instance->childHasBeenRendered('hQg9Jvy')) {
    $componentId = $_instance->getRenderedChildComponentId('hQg9Jvy');
    $componentTag = $_instance->getRenderedChildComponentTagName('hQg9Jvy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hQg9Jvy');
} else {
    $response = \Livewire\Livewire::mount('admin-side.components.settings', []);
    $html = $response->html();
    $_instance->logRenderedChild('hQg9Jvy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <div x-show="page === 'services'" class="w-full">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-side.service-page', [])->html();
} elseif ($_instance->childHasBeenRendered('iPwgRSV')) {
    $componentId = $_instance->getRenderedChildComponentId('iPwgRSV');
    $componentTag = $_instance->getRenderedChildComponentTagName('iPwgRSV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iPwgRSV');
} else {
    $response = \Livewire\Livewire::mount('admin-side.service-page', []);
    $html = $response->html();
    $_instance->logRenderedChild('iPwgRSV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/admin-side/index.blade.php ENDPATH**/ ?>