<div id="owl-demo" class="owl-carousel owl-theme">
    <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carouselItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item h-4/6 w-full">
            <img src="<?php echo e(asset("/storage/carousel/".$carouselItem->image->url)); ?>" alt="" class="h-full w-full">
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/customer-side/components/carousel.blade.php ENDPATH**/ ?>