<div class="flex-1 mx-7 py-5">
        <h1 class="font-black uppercase text-2xl">Pending Requests</h1>

        <div class="mt-1">
            <div class="w-full my-3">
                <div class="rounded-md w-full flex justify-between border items-center px-3">
                    <input type="text" placeholder="Enter keyword..." class="py-2 w-full focus:outline-none">
                <button class="flex justify-between items-center "><span class="material-icons">search</span></button>
                </div>
            </div>

            <div class="mt-2">
                <table class="w-full border">
                    <thead>
                        <tr class="text-left bg-blue-500 text-white">
                            <th class="py-3 uppercase font-medium pl-3">Trans. Code</th>
                            <th class="py-3 uppercase font-medium pl-3">Customer Info</th>
                            <th class="py-3 uppercase font-medium pl-3">Delivery Address</th>
                            <th class="py-3 uppercase font-medium">Provider</th>
                            <th class="py-3 uppercase font-medium">Avail. Services</th>
                            <th class="py-3 uppercase font-medium">Price (Php)</th>
                            <th class="py-3 uppercase font-medium">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($pendingrequests) > 0): ?>
                            <?php $__currentLoopData = $pendingrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white hover:bg-gray-100 border-b">
                                    <td class="uppercase font-medium pl-1 py-1"><?php echo e($request->transaction_code); ?></td>
                                    <td class="uppercase font-medium pl-1 py-1">
                                        <?php echo e($request->customer->firstname); ?> <?php echo e($request->customer->lastname); ?> <br>
                                        <span class="text-sm text-gray-400"><?php echo e($request->customer->contact_no); ?></span>
                                        
                                    </td>


                                    <td class="py-3 font-medium flex flex-col">
                                        <span class="text-sm"><?php echo e($request->delivery_address); ?></span>
                                    </td>
                                    <td class="py-3 uppercase font-medium">
                                        <?php echo e($request->serviceOffer->provider->user->firstname); ?> <?php echo e($request->serviceOffer->provider->user->lastname); ?><br>
                                        <span class="text-sm text-gray-400"><?php echo e($request->serviceOffer->provider->user->contact_no); ?></span>
                                    </td>
                                    <td class="py-3 uppercase font-medium">
                                        <?php $__currentLoopData = $request->requestItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($avail->service_name); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="py-3 uppercase font-medium"><?php echo e(number_format($request->totalAmount, 2, '.', ',')); ?></td>
                                    <td class="py-3 uppercase font-medium flex space-x-2">
                                        <?php if($request->category->admin == 1): ?>
                                            <button class="text-white bg-blue-500 px-2 py-2 rounded-md hover:shadow-md flex items-center space-x-2" wire:click="fullApproved(<?php echo e($request->id); ?>)">
                                                <span class="material-icons text-sm">thumb_up</span>
                                                <span>Full Approve</span>
                                            </button>
                                        <?php else: ?>
                                            <button class="text-white bg-blue-500 px-2 py-2 rounded-md hover:shadow-md flex items-center space-x-2" wire:click="acceptRequest(<?php echo e($request->id); ?>)">
                                                <span class="material-icons text-sm">thumb_up</span>
                                                <span>Accept</span>
                                            </button>
                                        <?php endif; ?>
                                        <button class="text-white bg-red-600 px-2 py-2 rounded-md hover:shadow-md flex items-center space-x-2">
                                            <span class="material-icons text-sm">thumb_down</span>
                                            <span>Decline</span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center py-3 text-red-500" colspan="7">No Request Found!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Accepted Requests -->
        <h1 class="font-black text-footer mt-5 uppercase text-2xl px-3 py-2 bg-orange-500 bg-opacity-25">Accepted Requests</h1>
        <div>
            <div class="w-full mb-3 mt-1">
                <div class="rounded-md w-full flex justify-between border items-center px-3">
                    <input type="text" placeholder="Enter keyword..." class="py-2 w-full focus:outline-none">
                <button class="flex justify-between items-center "><span class="material-icons">search</span></button>
                </div>
            </div>

            <div class="mt-2">
                <table class="w-full border">
                    <thead>
                        <tr class="text-left bg-blue-500 text-white">
                            <th class="py-3 uppercase font-medium pl-3">Trans. Code</th>
                            <th class="py-3 uppercase font-medium pl-3">Customer Info</th>
                            <th class="py-3 uppercase font-medium pl-3">Delivery Address</th>
                            <th class="py-3 uppercase font-medium">Provider</th>
                            <th class="py-3 uppercase font-medium">Avail. Services</th>
                            <th class="py-3 uppercase font-medium">Price (Php)</th>
                            <th class="py-3 uppercase font-medium">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($approvedrequests) > 0): ?>
                            <?php $__currentLoopData = $approvedrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white hover:bg-gray-100 border-b">
                                    <td class="uppercase font-medium pl-1 py-1"><?php echo e($request->transaction_code); ?></td>
                                    <td class="uppercase font-medium pl-1 py-1">
                                        <?php echo e($request->customer->firstname); ?> <?php echo e($request->customer->lastname); ?> <br>
                                        <span class="text-sm text-gray-400"><?php echo e($request->customer->contact_no); ?></span>
                                        
                                    </td>


                                    <td class="py-3 font-medium flex flex-col">
                                        <span class="text-sm"><?php echo e($request->delivery_address); ?></span>
                                    </td>
                                    <td class="py-3 uppercase font-medium">
                                        <?php echo e($request->serviceOffer->provider->user->firstname); ?> <?php echo e($request->serviceOffer->provider->user->lastname); ?><br>
                                        <span class="text-sm text-gray-400"><?php echo e($request->serviceOffer->provider->user->contact_no); ?></span>
                                    </td>
                                    <td class="py-3 uppercase font-medium">
                                        <?php $__currentLoopData = $request->requestItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($avail->service_name); ?><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="py-3 uppercase font-medium"><?php echo e(number_format($request->totalAmount, 2, '.', ',')); ?></td>
                                    <td class="py-3 uppercase font-medium flex space-x-2 items-center">
                                        <span class="bg-green-500 text-sm">Confirmed</span>
                                        <span class="material-icons text-green">done_all</span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td class="text-center py-3 text-red-500" colspan="6">No Request Found!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\E-TapServices\resources\views/livewire/admin-side/components/requests.blade.php ENDPATH**/ ?>