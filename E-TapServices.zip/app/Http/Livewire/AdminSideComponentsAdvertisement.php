<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AdminSideComponentsAdvertisement extends Component
{
    public function render()
    {
        return view('livewire.admin-side-components-advertisement');
    }
}
