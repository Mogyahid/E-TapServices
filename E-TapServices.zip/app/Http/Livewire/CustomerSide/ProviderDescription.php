<?php

namespace App\Http\Livewire\CustomerSide;

use Livewire\Component;

class ProviderDescription extends Component
{
    public function render()
    {
        return view('livewire.customer-side.provider-description');
    }
}
