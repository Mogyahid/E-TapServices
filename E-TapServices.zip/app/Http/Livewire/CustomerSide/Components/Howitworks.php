<?php

namespace App\Http\Livewire\CustomerSide\Components;

use Livewire\Component;

class Howitworks extends Component
{
    public function render()
    {
        return view('livewire.customer-side.components.howitworks');
    }
}
