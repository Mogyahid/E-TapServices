<?php

namespace App\Http\Livewire\AdminSide\Components;

use Livewire\Component;

class Users extends Component
{
    public function render()
    {
        return view('livewire.admin-side.components.users');
    }
}
