<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AppliedProviderFeedback extends Component
{
    public function render()
    {
        return view('livewire.applied-provider-feedback');
    }
}
