<?php

namespace App\Http\Livewire\ProviderSide\Components;

use Livewire\Component;

class Dashboard extends Component
{
    public function render()
    {
        return view('livewire.provider-side.components.dashboard');
    }
}
